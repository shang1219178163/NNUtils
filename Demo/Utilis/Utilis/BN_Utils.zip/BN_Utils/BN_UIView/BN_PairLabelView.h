//
//  BN_PairLabelView.h
//  BINAlertView
//
//  Created by hsf on 2018/8/1.
//  Copyright © 2018年 SouFun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BN_PairLabelView : UIView

@property (nonatomic, strong) NSNumber * type;

@property (nonatomic, strong) UILabel * labOne;
@property (nonatomic, strong) UILabel * labTwo;

@end
