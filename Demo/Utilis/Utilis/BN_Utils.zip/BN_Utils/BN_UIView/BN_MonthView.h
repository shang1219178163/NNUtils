//
//  BN_MonthView.h
//  BINAlertView
//
//  Created by hsf on 2018/7/31.
//  Copyright © 2018年 SouFun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BN_MonthView : UIView

@property (nonatomic, strong) UIImageView * imgView;
@property (nonatomic, strong) UILabel * labYear;
@property (nonatomic, strong) UILabel * labMonth;

@end
