//
//  BN_CTViewCellZero.h
//  HuiZhuBang
//
//  Created by BIN on 2018/4/13.
//  Copyright © 2018年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BN_CTViewCellZero : UICollectionViewCell

@end
