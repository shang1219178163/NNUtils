//
//  BN_CTViewCellSix.h
//  HuiZhuBang
//
//  Created by BIN on 2018/5/14.
//  Copyright © 2018年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BN_CTViewCellSix : UICollectionViewCell

@end
