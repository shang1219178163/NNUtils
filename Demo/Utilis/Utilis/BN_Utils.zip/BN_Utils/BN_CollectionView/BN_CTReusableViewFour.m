//
//  BN_CTReusableViewFour.m
//  HuiZhuBang
//
//  Created by BIN on 2018/5/14.
//  Copyright © 2018年 WeiHouKeJi. All rights reserved.
//

#import "BN_CTReusableViewFour.h"

#import "BN_Category.h"

@implementation BN_CTReusableViewFour

@end
