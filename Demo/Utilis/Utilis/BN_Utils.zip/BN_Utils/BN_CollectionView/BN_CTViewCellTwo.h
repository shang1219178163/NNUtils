//
//  BN_CTViewCellTwo.h
//  HuiZhuBang
//
//  Created by BIN on 2018/4/16.
//  Copyright © 2018年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BN_CTViewCellTwo : UICollectionViewCell

@end
