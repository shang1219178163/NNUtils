//
//  WHKTableViewTwentyNineCell.h
//  HuiZhuBang
//
//  Created by BIN on 2017/10/12.
//  Copyright © 2017年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UITableViewCell+AddView.h"

@interface WHKTableViewTwentyNineCell : UITableViewCell


@end
