//
//  WHKTableViewEightCell.m
//  HuiZhuBang
//
//  Created by BIN on 2017/8/18.
//  Copyright © 2017年 WeiHouKeJi. All rights reserved.
//

#import "WHKTableViewEightCell.h"
#import "BN_Globle.h"

@interface WHKTableViewEightCell ()


@end

@implementation WHKTableViewEightCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
     if (self) {
        [self createControls];
        
    }
    return self;
}

- (void)createControls{
    /*
     图片+文字
        +文字
     */
    
}



@end
