//
//  WHKTableViewTwentyOneCell.h
//  HuiZhuBang
//
//  Created by BIN on 2017/9/25.
//  Copyright © 2017年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UITableViewCell+AddView.h"

@interface WHKTableViewTwentyOneCell : UITableViewCell

@property (nonatomic, strong) UIButton * btnOne;
@property (nonatomic, strong) UIButton * btnTwo;

@end
