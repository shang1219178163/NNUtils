//
//  WHKTableViewThirtySixCell.h
//  HuiZhuBang
//
//  Created by BIN on 2017/11/9.
//  Copyright © 2017年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UITableViewCell+AddView.h"
#import "BN_ImgLabelView.h"

@interface WHKTableViewThirtySixCell : UITableViewCell

@property (nonatomic, strong) BN_ImgLabelView * imgLabView;

@end
