//
//  WHKTableViewSenventyFiveCell.h
//  HuiZhuBang
//
//  Created by BIN on 2018/4/26.
//  Copyright © 2018年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UITableViewCell+AddView.h"

@interface WHKTableViewSenventyFiveCell : UITableViewCell

@property (nonatomic, strong) UIImageView * iCon;

@end
