//
//  WHKTableViewElevenCell.h
//  HuiZhuBang
//
//  Created by BIN on 2017/9/13.
//  Copyright © 2017年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UITableViewCell+AddView.h"


@interface WHKTableViewElevenCell : UITableViewCell


@end
