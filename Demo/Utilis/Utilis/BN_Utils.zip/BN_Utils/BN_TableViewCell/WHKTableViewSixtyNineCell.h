//
//  WHKTableViewSixtyNineCell.h
//  HuiZhuBang
//
//  Created by BIN on 2018/4/10.
//  Copyright © 2018年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UITableViewCell+AddView.h"

@interface WHKTableViewSixtyNineCell : UITableViewCell

@property (nonatomic, strong) UILabel * labelOne;
@property (nonatomic, strong) UILabel * labelTwo;
@property (nonatomic, strong) UILabel * labelThree;
@property (nonatomic, strong) UILabel * labelFour;

@end
