//
//  WHKTableViewTwentyCell.h
//  HuiZhuBang
//
//  Created by BIN on 2017/9/25.
//  Copyright © 2017年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UITableViewCell+AddView.h"
#import "BN_ImgLabelView.h"

@interface WHKTableViewTwentyCell : UITableViewCell

@property (nonatomic, strong) BN_ImgLabelView * labViewOne;
@property (nonatomic, strong) BN_ImgLabelView * labViewTwo;
@property (nonatomic, strong) BN_ImgLabelView * labViewThree;


@end
