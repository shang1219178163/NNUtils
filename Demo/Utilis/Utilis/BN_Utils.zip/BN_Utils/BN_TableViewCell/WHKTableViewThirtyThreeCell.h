//
//  WHKTableViewThirtyThreeCell.h
//  HuiZhuBang
//
//  Created by BIN on 2017/10/30.
//  Copyright © 2017年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UITableViewCell+AddView.h"

@interface WHKTableViewThirtyThreeCell : UITableViewCell

@property (nonatomic, assign) CGSize  iconSize;
@property (nonatomic, strong) UIImageView * imgViewIcon;

@end
