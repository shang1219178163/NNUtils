//
//  WHKTableViewEightyFiveCell.h
//  HuiZhuBang
//
//  Created by BIN on 2018/5/18.
//  Copyright © 2018年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UITableViewCell+AddView.h"

#import "BN_TurnView.h"

@interface WHKTableViewEightyFiveCell : UITableViewCell

@property (nonatomic, strong) BN_TurnView * turnView;

@end
