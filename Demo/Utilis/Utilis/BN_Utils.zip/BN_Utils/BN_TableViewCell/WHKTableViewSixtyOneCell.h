//
//  WHKTableViewSixtyOneCell.h
//  HuiZhuBang
//
//  Created by BIN on 2018/3/28.
//  Copyright © 2018年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UITableViewCell+AddView.h"

@interface WHKTableViewSixtyOneCell : UITableViewCell


@end
