//
//  BN_CTReusableViewThree.h
//  HuiZhuBang
//
//  Created by BIN on 2018/5/14.
//  Copyright © 2018年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BN_CTReusableViewThree : UICollectionReusableView

@property (nonatomic, strong) UIView * lineView;

@end
