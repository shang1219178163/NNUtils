//
//  BN_CTViewLayoutZero.h
//  HuiZhuBang
//
//  Created by BIN on 2018/4/16.
//  Copyright © 2018年 WeiHouKeJi. All rights reserved.
//

/**
 系统flow布局
 */
#import <UIKit/UIKit.h>

@interface BN_CTViewLayoutZero : UICollectionViewFlowLayout

@end
