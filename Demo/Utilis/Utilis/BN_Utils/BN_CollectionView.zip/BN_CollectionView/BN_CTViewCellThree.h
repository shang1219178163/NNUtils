//
//  BN_CTViewCellThree.h
//  HuiZhuBang
//
//  Created by BIN on 2018/5/14.
//  Copyright © 2018年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BN_Globle.h"
#import <BN_Category/UICollectionViewCell+AddView.h>

@interface BN_CTViewCellThree : UICollectionViewCell


@end
