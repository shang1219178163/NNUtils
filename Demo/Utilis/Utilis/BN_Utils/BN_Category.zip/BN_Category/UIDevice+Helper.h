//
//  UIDevice+Helper.h
//  HuiZhuBang
//
//  Created by BIN on 2017/8/28.
//  Copyright © 2017年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIDevice (Helper)


@end
