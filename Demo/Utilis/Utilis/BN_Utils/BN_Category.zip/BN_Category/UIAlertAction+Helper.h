//
//  UIAlertAction+Helper.h
//  HuiZhuBang
//
//  Created by BIN on 2018/9/18.
//  Copyright © 2018年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIAlertAction (Helper)

@property (nonatomic, assign) NSInteger tag;//其他类使用该属性注意性能

@end

