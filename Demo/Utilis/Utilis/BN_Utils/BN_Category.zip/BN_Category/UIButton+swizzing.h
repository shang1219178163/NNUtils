//
//  UIButton+swizzing.h
//  HuiZhuBang
//
//  Created by BIN on 2017/12/27.
//  Copyright © 2017年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (swizzing)

@property (nonatomic,assign) NSTimeInterval custom_acceptEventInterval;

@end

