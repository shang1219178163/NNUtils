//
//  NSData+Helper.h
//  Location
//
//  Created by BIN on 2017/12/23.
//  Copyright © 2017年 Location. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface NSData (Helper)

+(NSData *)dataFromObj:(id)obj;


@end
