//
//  NSNumber+Helper.h
//  HuiZhuBang
//
//  Created by BIN on 2018/7/20.
//  Copyright © 2018年 WeiHouKeJi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSNumber (Helper)
/*弃用*/
//-(NSString *)stringWithIdentify:(NSString *)identify;

/**
 NSNumberFormatter格式化
 
 */
-(NSString *)BN_StringValue;


@end
