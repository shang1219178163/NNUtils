//
//  WHKTableViewFortyThreeCell.h
//  HuiZhuBang
//
//  Created by BIN on 2017/11/30.
//  Copyright © 2017年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UITableViewCell+AddView.h"

/**
 文字+文字(textField)
 */
@interface WHKTableViewFortyThreeCell : UITableViewCell


@end
