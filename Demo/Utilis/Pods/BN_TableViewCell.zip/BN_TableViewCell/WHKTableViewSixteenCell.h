//
//  WHKTableViewSixteenCell.h
//  HuiZhuBang
//
//  Created by BIN on 2017/9/14.
//  Copyright © 2017年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UITableViewCell+AddView.h"

/**
 图像+姓名+已结N单
     星星+信任值
 */
@interface WHKTableViewSixteenCell : UITableViewCell


@end
