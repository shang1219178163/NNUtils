//
//  WHKTableViewEightySixCell.h
//  HuiZhuBang
//
//  Created by BIN on 2018/5/18.
//  Copyright © 2018年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UITableViewCell+AddView.h"
#import "BN_CycleView.h"

/**
 文本循环往复
 */
@interface WHKTableViewEightySixCell : UITableViewCell

@property (nonatomic, strong) BN_CycleView * cycleView;

@end
