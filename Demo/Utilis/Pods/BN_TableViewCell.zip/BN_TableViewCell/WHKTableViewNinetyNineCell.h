//
//  WHKTableViewNinetyNineCell.h
//  HuiZhuBang
//
//  Created by BIN on 2018/6/22.
//  Copyright © 2018年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UITableViewCell+AddView.h"

//#import "WHKNetInfoRoomModel.h"
//#import "WHKNetInfoStyModel.h"

/**
 特殊需求(文字+栋舍选择+扫描)
 */
@interface WHKTableViewNinetyNineCell : UITableViewCell<UITextFieldDelegate>

//@property (nonatomic, copy) NSString * filterStr;
//@property (nonatomic, copy) NSString * sex;
//@property (nonatomic, weak) UIViewController * parConroller;
//@property (nonatomic, strong) void(^block)(WHKTableViewNinetyNineCell *view, WHKNetInfoRoomModel *modelRoom, WHKNetInfoStyModel *modelSty, id obj);

@end

