//
//  WHKTableViewHeaderFooterOneView.h
//  HuiZhuBang
//
//  Created by hsf on 2018/4/2.
//  Copyright © 2018年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WHKTableViewHeaderFooterOneView : UITableViewHeaderFooterView

@end
