//
//  WHKTableViewFourtyNineCell.h
//  HuiZhuBang
//
//  Created by BIN on 2018/7/10.
//  Copyright © 2018年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UITableViewCell+AddView.h"

/**
 文字+文字+文字+文字
 */
@interface WHKTableViewFourtyNineCell : UITableViewCell

@property (nonatomic, strong) UILabel * labTitle;
@property (nonatomic, strong) UILabel * labLeft;
@property (nonatomic, strong) UILabel * labCenter;
@property (nonatomic, strong) UILabel * labRight;

@end
