//
//  WHKTableViewEightyCell.h
//  HuiZhuBang
//
//  Created by BIN on 2018/5/8.
//  Copyright © 2018年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UITableViewCell+AddView.h"
#import "BN_ItemsView.h"

/**
 类微博(上边文字秒速,底下图片)
 */
@interface WHKTableViewEightyCell : UITableViewCell

@property (nonatomic, strong) BN_ItemsView *itemsView;

@end
