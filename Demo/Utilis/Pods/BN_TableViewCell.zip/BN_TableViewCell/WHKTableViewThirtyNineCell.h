//
//  WHKTableViewThirtyNineCell.h
//  HuiZhuBang
//
//  Created by BIN on 2017/11/14.
//  Copyright © 2017年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UITableViewCell+AddView.h"

/**
 文字+文字(BN_TextField)
 */
@interface WHKTableViewThirtyNineCell : UITableViewCell


@end
