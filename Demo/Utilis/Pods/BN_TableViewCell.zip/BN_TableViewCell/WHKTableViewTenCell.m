//
//  WHKTableViewTenCell.m
//  HuiZhuBang
//
//  Created by BIN on 2017/8/22.
//  Copyright © 2017年 WeiHouKeJi. All rights reserved.
//

#import "WHKTableViewTenCell.h"
#import "BN_Globle.h"
#import "NSObject+Helper.h"

@interface WHKTableViewTenCell ()


@end

@implementation WHKTableViewTenCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self createControls];
        
    }
    return self;
}

- (void)createControls{
   
}



@end
