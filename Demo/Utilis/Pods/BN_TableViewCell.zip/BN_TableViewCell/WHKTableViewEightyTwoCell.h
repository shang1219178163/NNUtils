//
//  WHKTableViewEightyTwoCell.h
//  HuiZhuBang
//
//  Created by BIN on 2018/5/11.
//  Copyright © 2018年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UITableViewCell+AddView.h"
#import "BN_UserView.h"

/**
 用户
 评论信息
 */
@interface WHKTableViewEightyTwoCell : UITableViewCell

@property (nonatomic, strong) BN_UserView *userView;

@end
