//
//  WHKTableViewFortyCell.h
//  HuiZhuBang
//
//  Created by BIN on 2017/11/15.
//  Copyright © 2017年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UITableViewCell+AddView.h"

/**
 图片1+文字2+文字3+btn
      文字4+文字5
 */
@interface WHKTableViewFortyCell : UITableViewCell


@end
