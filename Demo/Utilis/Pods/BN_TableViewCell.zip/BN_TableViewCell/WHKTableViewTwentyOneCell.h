//
//  WHKTableViewTwentyOneCell.h
//  HuiZhuBang
//
//  Created by BIN on 2017/9/25.
//  Copyright © 2017年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UITableViewCell+AddView.h"

/**
 文字1+文字2+BTN3+BTN4
 */
@interface WHKTableViewTwentyOneCell : UITableViewCell

@property (nonatomic, strong) UIButton * btnOne;
@property (nonatomic, strong) UIButton * btnTwo;

@end
