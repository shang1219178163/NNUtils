//
//  WHKTableViewElevenCell.h
//  HuiZhuBang
//
//  Created by BIN on 2017/9/13.
//  Copyright © 2017年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UITableViewCell+AddView.h"

/**
 文字+文字+单选按钮
 */
@interface WHKTableViewElevenCell : UITableViewCell


@end
