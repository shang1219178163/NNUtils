//
//  WHKTableViewFiftyEightCell.h
//  HuiZhuBang
//
//  Created by BIN on 2018/3/26.
//  Copyright © 2018年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UITableViewCell+AddView.h"

/**
 文字+文字 | 文字+文字
 */
@interface WHKTableViewFiftyEightCell : UITableViewCell

@property (nonatomic, strong) UILabel * labelRightSub;
@property (nonatomic, strong) UIView * lineVert;


@end
