//
//  WHKTableViewFifteenCell.h
//  HuiZhuBang
//
//  Created by BIN on 2017/9/14.
//  Copyright © 2017年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UITableViewCell+AddView.h"

/**
  -----------------文字2+文字1
 */
@interface WHKTableViewFifteenCell : UITableViewCell



@end
