//
//  WHKHeaderFooterViewZero.h
//  HuiZhuBang
//
//  Created by BIN on 2018/4/2.
//  Copyright © 2018年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UITableViewHeaderFooterView+AddView.h"

/**
 指示器 标题     子标题
 */
@interface WHKHeaderFooterViewZero : UITableViewHeaderFooterView


@end
