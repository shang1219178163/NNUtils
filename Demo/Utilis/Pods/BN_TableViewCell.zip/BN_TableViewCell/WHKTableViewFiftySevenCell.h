//
//  WHKTableViewFiftySevenCell.h
//  HuiZhuBang
//
//  Created by BIN on 2018/3/26.
//  Copyright © 2018年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UITableViewCell+AddView.h"

/**
 |+文字+箭头
 |+文字
 */
@interface WHKTableViewFiftySevenCell : UITableViewCell

@property (nonatomic, strong) UILabel * labelLeftPrefix;


@end
