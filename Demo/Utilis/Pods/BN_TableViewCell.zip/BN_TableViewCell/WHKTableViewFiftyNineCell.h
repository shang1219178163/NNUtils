//
//  WHKTableViewFiftyNineCell.h
//  HuiZhuBang
//
//  Created by BIN on 2018/6/22.
//  Copyright © 2018年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UITableViewCell+AddView.h"
#import "BN_AlertViewOne.h"

/**
 文字+pickerView(原生)
 */
@interface WHKTableViewFiftyNineCell : UITableViewCell

@property (nonatomic, strong) NSDictionary * dic;
@property (nonatomic, strong) void(^block)(WHKTableViewFiftyNineCell *view, NSString * string, NSIndexPath * indexPath);

@end
