//
//  WHKHeaderFooterViewTwo.h
//  HuiZhuBang
//
//  Created by BIN on 2018/5/11.
//  Copyright © 2018年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UITableViewHeaderFooterView+AddView.h"

/**
 图片+文字+按钮
 */
@interface WHKHeaderFooterViewTwo : UITableViewHeaderFooterView

@end
