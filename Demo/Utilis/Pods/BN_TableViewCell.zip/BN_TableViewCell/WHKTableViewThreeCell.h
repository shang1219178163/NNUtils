//
//  WHKTableViewThreeCell.h
//  HuiZhuBang
//
//  Created by BIN on 2017/8/16.
//  Copyright © 2017年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UITableViewCell+AddView.h"

/**
 图片1+文字2+文字3+图片6
      文字4+文字5
 */
@interface WHKTableViewThreeCell : UITableViewCell


@end
