//
//  WHKTableViewThirtyFourCell.h
//  HuiZhuBang
//
//  Created by BIN on 2017/10/31.
//  Copyright © 2017年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UITableViewCell+AddView.h"

/**
 文字1+文字3
 文字2
 */
@interface WHKTableViewThirtyFourCell : UITableViewCell


@end
