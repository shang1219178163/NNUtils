//
//  WHKTableViewTwoCell.h
//  HuiZhuBang
//
//  Created by BIN on 2017/8/14.
//  Copyright © 2017年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UITableViewCell+AddView.h"

/**
 图片1+文字2+文字3
      文字4
 */
@interface WHKTableViewTwoCell : UITableViewCell


@end
