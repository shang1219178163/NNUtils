//
//  WHKTableViewSenventySixCell.h
//  HuiZhuBang
//
//  Created by BIN on 2018/4/27.
//  Copyright © 2018年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UITableViewCell+AddView.h"

static CGFloat  kH_Fold = 80;

/**
 (可折叠评论)
 文字1+文字2
      文字3
       btn
 */
@interface WHKTableViewSenventySixCell : UITableViewCell

//@property (nonatomic, strong) void(^block)(WHKTableViewSenventySixCell * view, UIButton * btn);

@end
