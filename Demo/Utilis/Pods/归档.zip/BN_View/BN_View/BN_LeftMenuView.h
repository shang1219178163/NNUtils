//
//  WHKLeftMenuView.h
//  HuiZhuBang
//
//  Created by BIN on 2017/9/16.
//  Copyright © 2017年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BN_LeftMenuView : UIView

-(void)show;

-(void)dismiss;

@end
