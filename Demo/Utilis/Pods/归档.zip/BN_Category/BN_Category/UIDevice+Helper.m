
//
//  UIDevice+Helper.m
//  HuiZhuBang
//
//  Created by BIN on 2017/8/28.
//  Copyright © 2017年 WeiHouKeJi. All rights reserved.
//

#import "UIDevice+Helper.h"

@interface UIDevice (Private)

@end

@implementation UIDevice (Helper)


@end
