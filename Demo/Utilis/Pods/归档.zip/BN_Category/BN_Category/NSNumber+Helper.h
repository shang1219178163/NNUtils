//
//  NSNumber+Helper.h
//  HuiZhuBang
//
//  Created by BIN on 2018/7/20.
//  Copyright © 2018年 WeiHouKeJi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSNumber (Helper)

/**
 NSNumberFormatter格式化
 
 */
-(NSString *)stringValue;


@end
