//
//  UIImageView+ClickImageEnlarge.h
//  Test
//
//  Created by ibokan on 14-4-1.
//  Copyright (c) 2014年 ibokan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImageView (ClickImageEnlarge)

//-(void)showImage:(UIImageView*)avatarImageView;

-(void)showImageEnlarge;

@end

