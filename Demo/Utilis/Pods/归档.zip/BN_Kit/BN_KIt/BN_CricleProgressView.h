//
//  BN_CricleProgressView.h
//  HuiZhuBang
//
//  Created by BIN on 2018/5/14.
//  Copyright © 2018年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BN_CricleProgressView : UIView

@property (nonatomic, assign) CGFloat progress;
@property (nonatomic, strong) UILabel *label;

@end
