//
//  BNNavigationController.h
//  ProductTemplet
//
//  Created by hsf on 2018/9/30.
//  Copyright © 2018年 BN. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BNNavigationController : UINavigationController

@end
