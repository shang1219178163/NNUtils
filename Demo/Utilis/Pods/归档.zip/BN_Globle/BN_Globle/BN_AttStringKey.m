//
//  BNAttributedStringKey.m
//  ProductTemplet
//
//  Created by hsf on 2018/8/30.
//  Copyright © 2018年 BN. All rights reserved.
//

#import "BN_AttStringKey.h"

@implementation BN_AttStringKey

+(NSString *)obj{
    return NSStringFromSelector(_cmd);
}

+(NSString *)title{
    return NSStringFromSelector(_cmd);
}

+(NSString *)controlName{
    return NSStringFromSelector(_cmd);
}

+(NSString *)font{
    return NSStringFromSelector(_cmd);
}

+(NSString *)backgroundColor{
    return NSStringFromSelector(_cmd);
}

+(NSString *)textColor{
    return NSStringFromSelector(_cmd);
}

+(NSString *)textColor_H{
    return NSStringFromSelector(_cmd);
}

+(NSString *)imgName{
    return NSStringFromSelector(_cmd);
}

+(NSString *)imgName_H{
    return NSStringFromSelector(_cmd);
}


//+(NSString *)foregroundColor{
//    return NSStringFromSelector(_cmd);
//
//}
//
//+(NSString *)foregroundColor{
//    return NSStringFromSelector(_cmd);
//
//}

@end
