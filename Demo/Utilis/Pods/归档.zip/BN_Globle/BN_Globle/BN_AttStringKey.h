//
//  BN_AttStringKey.h
//  ProductTemplet
//
//  Created by hsf on 2018/8/30.
//  Copyright © 2018年 BN. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BN_AttStringKey : NSObject

+(NSString *)obj;

+(NSString *)title;

+(NSString *)controlName;

+(NSString *)font;

+(NSString *)backgroundColor;

+(NSString *)textColor;

+(NSString *)textColor_H;

+(NSString *)imgName;

+(NSString *)imgName_H;


    
@end
