# BN_Globle
基础宏,常量值,第三方appKey配置
