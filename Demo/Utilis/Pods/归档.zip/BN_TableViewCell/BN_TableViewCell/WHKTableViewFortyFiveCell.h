//
//  WHKTableViewFortyFiveCell.h
//  HuiZhuBang
//
//  Created by BIN on 2017/12/15.
//  Copyright © 2017年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UITableViewCell+AddView.h"

@interface WHKTableViewFortyFiveCell : UITableViewCell

@property (nonatomic, strong) UIImageView * iConEP;
@property (nonatomic, assign) CGSize iConSize;

@end
