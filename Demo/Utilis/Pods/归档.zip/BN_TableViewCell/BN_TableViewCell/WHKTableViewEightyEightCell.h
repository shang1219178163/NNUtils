//
//  WHKTableViewEightyEightCell.h
//  HuiZhuBang
//
//  Created by BIN on 2018/6/8.
//  Copyright © 2018年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UITableViewCell+AddView.h"

#import "PPNumberButton.h"

@interface WHKTableViewEightyEightCell : UITableViewCell

@property (nonatomic, strong) PPNumberButton * numberBtnRight;

@end
