//
//  BN_TableViewHeaderFooterZeroView.m
//  HuiZhuBang
//
//  Created by hsf on 2018/4/2.
//  Copyright © 2018年 WeiHouKeJi. All rights reserved.
//

#import "BN_TableViewHeaderFooterZeroView.h"
#import "BN_Globle.h"

@implementation BN_TableViewHeaderFooterZeroView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
