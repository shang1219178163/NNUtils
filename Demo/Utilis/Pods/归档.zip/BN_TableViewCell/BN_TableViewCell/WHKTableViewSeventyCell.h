//
//  WHKTableViewSeventyCell.h
//  HuiZhuBang
//
//  Created by BIN on 2018/4/18.
//  Copyright © 2018年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UITableViewCell+AddView.h"

@interface WHKTableViewSeventyCell : UITableViewCell

@property (nonatomic, strong) UILabel * labelOne;
@property (nonatomic, strong) UILabel * labelTwo;
@property (nonatomic, strong) UILabel * labelThree;

@end
