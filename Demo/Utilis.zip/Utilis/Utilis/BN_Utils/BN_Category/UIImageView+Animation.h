//
//  UIImageView+Animation.h
//  BN_Animation
//
//  Created by hsf on 2018/9/26.
//  Copyright © 2018年 whkj. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImageView (Animation)

- (void)addAnimWithImageArr:(NSArray *)imageArr;

@end

