//
//  WHKTableViewThirtySevenCell.h
//  HuiZhuBang
//
//  Created by BIN on 2017/11/9.
//  Copyright © 2017年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UITableViewCell+AddView.h"

@interface WHKTableViewThirtySevenCell : UITableViewCell



@end
