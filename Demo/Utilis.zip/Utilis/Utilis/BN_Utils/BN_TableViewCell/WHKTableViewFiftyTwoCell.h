//
//  WHKTableViewFiftyTwoCell.h
//  HuiZhuBang
//
//  Created by BIN on 2018/3/24.
//  Copyright © 2018年 WeiHouKeJi. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UITableViewCell+AddView.h"

@interface WHKTableViewFiftyTwoCell : UITableViewCell

@property (nonatomic, strong) UILabel * labelLeftPrefix;

@end
